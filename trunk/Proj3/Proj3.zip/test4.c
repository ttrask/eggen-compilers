

int fib(int n)
{
	int result;
	
	r=(((x+1))*((x/(x-y))));
	b=bbbb/123432*5+ func(r, b);
	return num+5*num;
	
	if (n < 2)
		return n;

	fib(4, string);
	result = fib(n-1, string) + (fib(n-2) * fib(n-3));
	return result;
}

int main(void)
{
	int n; int i;
	i = 0;
	n==3;
	n = input();
	while (i <= n) {
		output(fib(i));
		i = i + 1;
	}

	return 0;
}
