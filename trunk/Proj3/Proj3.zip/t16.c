/* good _t16 */
int main(int x)
{
   int a;
   if(x > 2)
   {
      x = a + 1;
   }
}