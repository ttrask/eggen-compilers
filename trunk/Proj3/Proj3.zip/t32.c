
/* good _t32 */
int main(void)
{
if (this==10) {
that[this] = 10;
}
}