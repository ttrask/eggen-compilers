/* should parse while and if and function */
int q;

void f(void){
	{
	int i;
	}
	{
	int j;
	j=2;
	}
	{
	int i;
	i=2;
	}
	return;
}



int car(int j)
{
	int q[3];
	
	if(j==2){
		return 2;
	}
	else{
		return 2;
	}
   
   q[1] = func(func(1));
   q[func(1)] = func(q[1]*j+1);
   q[1] = j;
   return q[1];
   //return 3*1 + j*2;
   //return 3.1;
}

void test2(int y, float z, int x, void t){
	return;
}

void monkey(int x, int y)
{
   int a[4];
   int b;
   //int x;
   int c;
   //int b;
   
   b=b/2;
   while (b==3)
   {
       int x;
       x=q+2;
   }
   
   if (c==b)
   {
   		float x;
   		float y;
   		
       a[2+1]=3;
       a[car(1)]=3;
       c=car(4);
   }  
   return ;
}


int func(int j){
	return 1;
}