
void monkey(void)
{                        /* good */
   int q;    
   void a[4];
   int b;
   void c;

   b=b/2;
   while (b==3)
   {
       int x;
       x=q+2;
   }
   if (c==b)
   {
       a[car(1)]=3;
       a[2+1]=3;
       c=car(4);
   }
}

int d;
void main(void)
{
   int q[3];
   q=j+4;
}