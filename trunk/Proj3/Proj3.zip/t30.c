
/* bad  _t30 */
void main(void)
{
while (true) {
that = 10;
}


}

extra