
/* good _t17 */
int main(void)
{
   int a;
   if(a < 8) 
   {
      a;
   }
}